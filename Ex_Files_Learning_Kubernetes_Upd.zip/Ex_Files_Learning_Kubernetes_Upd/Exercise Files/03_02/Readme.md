# Chapter 03_02- Setting up minikube and kubectl on windows

Please see the minikube-windows-setup.docx for setup information.

After completing setup, to start up minikube on windows run:

`minikube start --vm-driver="hyperv" --hyperv-virtual-switch="minikube"`

Read more about drivers here: [https://minikube.sigs.k8s.io/docs/drivers/]
